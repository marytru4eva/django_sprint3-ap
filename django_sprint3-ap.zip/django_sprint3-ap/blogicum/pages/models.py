"""Models for pages app."""
