"""Tests for pages app."""
